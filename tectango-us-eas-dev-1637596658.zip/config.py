import os
import boto3
from botocore.exceptions import ClientError


class Config(object):
    #region = "us-east-1"
    #host = "https://tecnics-dev.oktapreview.com"
    # app_id = "0oa1088m2uxGYD8J80h8"
    # dynamodb_tbl_name = "client_config_data"
    region = os.environ['AWS_KMS_REGION']
    host = os.environ['TECNICS_DEV_HOST']
    app_id = os.environ['TECTANGO_ROAMING_APP_ID']
    dynamodb_tbl_name = os.environ['TABLE_NAME']

    dynamodb = boto3.resource('dynamodb', region_name=region)
    table = dynamodb.Table(dynamodb_tbl_name)
    try:
        response = table.get_item(Key={"KEY":"okta_api"})
        api_key = response['Item']['VALUE']
        response = table.get_item(Key={"KEY": "aws_account_number"})
        aws_account_number = response['Item']['VALUE']
        response = table.get_item(Key={"KEY": "aws_key_id"})
        aws_key_id = response['Item']['VALUE']
    except ClientError as e:
        print(e.response['Error']['Message'])


class DevelopmentConfig(Config):
    TEMPLATES_AUTO_RELOAD = True
    DEBUG = True


class TestingConfig(Config):
    TESTING = True


class ProductionConfig(Config):
    DEBUG = False


app_config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig
}
































# region = 'us-east-1'
# host = 'https://tecnics-dev.oktapreview.com'
# app_id = '0oa1088m2uxGYD8J80h8'
# dynamodb_tbl_name = "client_config_data"