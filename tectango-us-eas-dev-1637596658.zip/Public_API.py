import os
import boto3
import asyncio

import requests

import asyncio
import requests
from okta_jwt_verifier import JWTVerifier
#from helpers.route_helpers import client, token_client
from init import app
from flask import request, jsonify
from config import Config
from okta_jwt_verifier import JWTVerifier
from botocore.exceptions import ClientError
from http_exception.error_handlers import PUBLIC_KEY_FORBIDDEN, SOMETHING_WENT_WRONG

# dynamodb_table_name = os.environ['DYNAMODB_TABLE_NAME']
# print(dynamodb_table_name)

# @app.route('/public/api/v1/config/<hostname>', methods=['POST'])
# def public_api_config(hostname):
#     try:
#         dynamodb_table_name = os.environ['DYNAMODB_TABLE_NAME']
#         print(dynamodb_table_name)
#         #dynamodb_table_name = "tbl_dev_credenti_config_v1"
#         payload = request.json
#         host_name = hostname
#         product = payload.get('productName')
#         dynamodb = boto3.resource('dynamodb', region_name=Config.region)
#         table = dynamodb.Table(dynamodb_table_name)
#         response = table.get_item(Key={'pk_cust_r53_domain': host_name, 'sk_product_sku': product})
#         remove_list = [host_name, product]
#         if str(response).__contains__(host_name) and str(response).__contains__(product):
#             config_data = response['Item']
#             final_config_data = dict([(key, val) for key, val in
#                                       config_data.items() if val not in remove_list])
#             # # returns dictionary after removal
#             #aws_kms_arn = final_config_data['aws_kms_arn']
#             return final_config_data
#         else:
#             #return error_message("Hostname or Product not found")
#             return PUBLIC_KEY_FORBIDDEN
#     except ClientError as e:
#         # print(e.response['Error']['Message'])
#         return SOMETHING_WENT_WRONG




















# async def jwt_verifier(issuer, client_id, access_token):
#     try:
#         jwt_verifier = JWTVerifier(issuer, client_id, 'api://default')
#         await jwt_verifier.verify_access_token(access_token)
#         print('Token validated successfully.')
#         return "Token validated successfully."
#     except Exception as e:
#         print(e)
#         return str(e)
#
# @app.route('/api/v1/authn/introspect')
# async def introspect_api():
#     # payload = request.json
#     # access_token  = payload.get('accessToken')
#     # issuer  = payload.get('issuer')
#     # client_id  = payload.get('clientId'
#     # access_token = payload.args.get("access_token")
#     issuer = "https://tecnics-stage.oktapreview.com/oauth2/default"
#     client_id = "0oa128gzo8nQxZFGY0h8"
#     access_token_1 = "eyJraWQiOiJrNkh6WVFXYi1NaG1OX21DSWF6dmJGZXlreUxfSnJKYTdpV2d2RTJUYXcwIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULmdHYUVsbjdGWVF6LXViWjBfeV9sVmcwSUJRbVFleUxRQzFSbDFJNHhHZzAiLCJpc3MiOiJodHRwczovL3RlY25pY3Mtc3RhZ2Uub2t0YXByZXZpZXcuY29tL29hdXRoMi9kZWZhdWx0IiwiYXVkIjoiYXBpOi8vZGVmYXVsdCIsImlhdCI6MTYzNjQ1MjUyMSwiZXhwIjoxNjM2NDU2MTIxLCJjaWQiOiIwb2ExMmJnbGgwZE1Pek1yOTBoOCIsInVpZCI6IjAwdTEyYTF5cnYwcDFhaUpGMGg4Iiwic2NwIjpbIm9wZW5pZCIsImVtYWlsIl0sInN1YiI6InNhbWFudGhhLnNtaXRoQGNyZWRlbnRpLmlvIn0.Y7XAU7lS1FXYgCj9LA_AB2rbxiT5LFbi5imlz6McamG9ebJZq66Bq9h5sF9taK_q1Yzos_nkkcrrrdp5yTBk0ENFwJazXnaJjyMqEXRzI3MuRDiwmjIBrFhLBKlmGrdwaY3UBymx4Ye0VhjB7Vb08E3cz4K93hgwdzMZAWxbpHcCPM_wBQHSTJtwvBN3Zlu9jnwTnidvAvCROgGUSUruV4IEZ29ysXPX7bYAg5uEKL9ihrb9oz0lk7b2tMjQNDD8yOvrgMqtw9c4FAb9TOgQTI8C0gkNao4YS2pAvYyoguVcRrrYR6JRcMtk812jcs6d7R-3EVWJpkls7cPRl1DzKQ"
#     access_token = "eyJraWQiOiJrNkh6WVFXYi1NaG1OX21DSWF6dmJGZXlreUxfSnJKYTdpV2d2RTJUYXcwIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULkpldDJQbENYUjdnLXlYTjNVVXcydWdTMHBQdGU3UnNhZFFXWUczRk5YOHMiLCJpc3MiOiJodHRwczovL3RlY25pY3Mtc3RhZ2Uub2t0YXByZXZpZXcuY29tL29hdXRoMi9kZWZhdWx0IiwiYXVkIjoiYXBpOi8vZGVmYXVsdCIsImlhdCI6MTYzNjQ1NzE2OCwiZXhwIjoxNjM2NDYwNzY4LCJjaWQiOiIwb2ExMmJnbGgwZE1Pek1yOTBoOCIsInVpZCI6IjAwdTEyYTF5cnYwcDFhaUpGMGg4Iiwic2NwIjpbImVtYWlsIiwib3BlbmlkIl0sInN1YiI6InNhbWFudGhhLnNtaXRoQGNyZWRlbnRpLmlvIn0.JlfGjfS7-wqocBeNG4NHlW3L1vBsmZUW8G7LnxEBZqH_X4OpjUl9RtVSyn7yudHaRpqinivgeG4rUJVhQBGoVWznG0P1A4n-5BvDNhbiI0VTYFM7RAWITlU_Svd0MpU6jM5wesBdPBHwI_bDD72WPXHSYNFd1hC8cLOxkizE9Kr4YdsjNyRZ3khWLsEH60EZIKcuO0wRZabss_UwAdDKPszCYWi5XR2ieaxm88kVkjoNCXKvQortFfByMCSOKb-jCR6hjZfN_y4LKHiKKeL7KFJJ0X8LGjv4JckY1n-bVwZEOL9Rh6aHAqOw-hXDeb0IHJoxKjBz-b4-tCU1xHKSEA"
#
#     response = await jwt_verifier(issuer, client_id, access_token)
#     jwt_verifier = JWTVerifier(issuer, client_id, 'api://default')
#     await jwt_verifier.verify_access_token(access_token)
#     print('Token validated successfully.')
#     return "Token validated successfully."
#     return response












#dynamodb_table_name = "tbl_dev_credenti_config_v1"










# print(jwt_verifier.parse_token(JWT_1))
        # kid = jwt_verifier.parse_token(JWT)[0]['kid']
        # iss = jwt_verifier.parse_token(JWT)[1]['iss']
        # aud = jwt_verifier.parse_token(JWT)[1]['aud']
        # cid = jwt_verifier.parse_token(JWT)[1]['cid']
        # print("kid:", kid)
        # print("iss:", iss)
        # print("aud:", aud)
        # print("cid:", cid)






# loop = asyncio.get_event_loop()
# loop.run_until_complete(introspect())
#



# print(jwt_verifier.parse_token(JWT))
#         kid = jwt_verifier.parse_token(JWT)[0]['kid']
#         iss = jwt_verifier.parse_token(JWT)[1]['iss']
#         aud = jwt_verifier.parse_token(JWT)[1]['aud']
#         cid = jwt_verifier.parse_token(JWT)[1]['cid']
#         print("kid:", kid)
#         print("iss:", iss)
#         print("aud:", aud)
#         print("cid:", cid)
# @app.route('/api/v1/authn/introspect', methods=['POST'])
# def introspect_api():
#     try:
#         payload = request.json
#         ISSUER = payload.get('issuer')
#         CLIENT_ID = payload.get('client_id')
#         jwt_verifier = JWTVerifier(ISSUER, CLIENT_ID, 'api://default')
#         JWT = get_jwks_uri(ISSUER)
#         await jwt_verifier.verify_access_token(JWT)
#         print('Token validated successfully.')
#         # loop = asyncio.get_event_loop()
#         # loop.run_until_complete(main())
#     except ClientError as e:
#         print(e.response['Error']['Message'])
#         return SOMETHING_WENT_WRONG
#
#
# def get_jwks_uri(issuer):
#     request_headers = {
#         "Accept": "application/json",
#         "Content-Type": "application/json",
#         #"Authorization": 'Bearer {}'.format(bearer_token)
#     }
#     response = requests.get(issuer + ".well-known/oauth-authorization-server", headers=request_headers)
#     print("\nResponse: ", response.text)
#     return response.text
#
#
# def get_keys(issuer):
#     response = requests.get(issuer + "v1/keys")
#     print("\nResponse: ", response.text)
#     return response.text


# jwt_verifier = JWTVerifier('${ISSUER}', '${CLIENT_ID}', 'api://default')





























#host_name = request.args.get('hostname')
# def error_message(code, name, description):
#     #{'message': {'error': {'body': error_message}}}
#     error_msg = {
#     "code": code,
#     "name": name,
#     "description": description
#     }
#     return error_msg

# @app.route('/api/v1/', methods=['POST'])
# def public_api():
#     try:
#         config_data = {}
#         payload = request.json
#         #host_name = hostname
#         host_name = request.args.get('hostname')
#         #print(host_name)
#         product = payload.get('productName')
#         dynamodb = boto3.resource('dynamodb', region_name=Config.region)
#         table = dynamodb.Table("tbl_dev_credenti_config_v1")
#         #response = table.get_item(Key={"pk_cust_r53_domain": host_name})
#         response = table.get_item(Key={'pk_cust_r53_domain': host_name, 'sk_product_sku': product})
#         remove_list = [host_name, product]
#         if str(response).__contains__(host_name) and str(response).__contains__(product):
#             config_data = response['Item']
#             #new_dict = {key: val for key, val in config_data.items() if val != host_name}
#             new_dict = dict([(key, val) for key, val in
#             config_data.items() if val not in remove_list])
#             # Printing dictionary after removal
#             print("The dictionary after remove is : " + str(new_dict))
#             return new_dict
#             # config_data = response['Item']
#             # for key, value in config_data.items():
#             #     if value != host_name and product:
#             #         config_data.update(key, value)
#             #     # if data != "pk_cust_r53_domain":
#             #     #     print(config_data)
#             # return config_data
#
#             # config_data = response['Item']
#             # if str(config_data) != "pk_cust_r53_domain":
#             #     return str(config_data)
#             #return response['Item'] != host_name and product
#         else:
#             return error_message("Hostname or Product not found")
#     except ClientError as e:
#         #print(e.response['Error']['Message'])
#         return error_message(e.response['Error']['Message'])
#     # except Exception as e:
#     #     print("In exception")
#     #     return error_message(e)
